# by McGamer
from typing import Any, Coroutine

from aiohttp import ClientError, ClientSession, ClientTimeout, ContentTypeError


class Pterodactyl:
    def __init__(self, pterodactyl_url: str, api_key: str) -> None:
        self._pterodactyl_url = pterodactyl_url
        self._api_key = api_key
        self._headers = {
            "Authorization": f"Bearer {api_key}"
        }

    async def request(self, method: str, url: str, **kwargs) -> dict[str, Any]:
        async with ClientSession(headers=self._headers, timeout=ClientTimeout(total=3.0)) as session:
            async with session.request(method=method, url=url, **kwargs) as response:
                data = {
                    "status": response.status
                }
                try:
                    data["data"] = await response.json()
                except ContentTypeError:
                    data["data"] = await response.text()

                return data

    async def get_nodes(self) -> list[dict]:
        response = await self.request("GET", f"{self._pterodactyl_url}/api/application/nodes?include=location,servers")
        return list(map(lambda data: data.get("attributes"), response["data"].get("data", [])))

    async def get_node_configuration(self, _id: int) -> dict[str, Any]:
        response = await self.request("GET", f"{self._pterodactyl_url}/api/application/nodes/{_id}/configuration")
        return response["data"]

    async def node_is_enabled(self, scheme: str, fqdn: str, daemon_listen: int, token: str) -> bool:
        try:
            response = await self.request("GET", f"{scheme}://{fqdn}:{daemon_listen}/api/servers", headers={
                "Authorization": f"Bearer {token}"
            })
        except ClientError:
            return False

        return True if response["status"] == 200 else False
