# by McGamer
from os import getenv

from disnake import Intents
from disnake.ext.commands import InteractionBot
from dotenv import load_dotenv

from pterodactyl import Pterodactyl

load_dotenv()

bot = InteractionBot(intents=Intents.all())
pterodactyl = Pterodactyl(getenv("PTERODACTYL_URL"), getenv("PTERODACTYL_API_KEY"))

bot.load_extensions("./extensions")

if __name__ == "__main__":
    bot.run(getenv("TOKEN"))
