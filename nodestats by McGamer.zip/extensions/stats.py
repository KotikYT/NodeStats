# by McGamer
from datetime import datetime
from os import getenv

from disnake import ButtonStyle, Embed, TextChannel
from disnake.ext.commands import Cog, InteractionBot
from disnake.ext.tasks import loop
from disnake.ui import ActionRow, Button
from dotenv import load_dotenv
from loguru import logger

from pterodactyl import Pterodactyl

load_dotenv()


class Stats(Cog):
    def __init__(self, bot: InteractionBot) -> None:
        self._cache = {
            "locations": {},
            "pterodactyl_is_enabled": True,
            "client_is_enabled": True,
            "site_is_enabled": True,
            "message_id": 0
        }
        self.bot = bot
        self.pterodactyl = Pterodactyl(getenv("PTERODACTYL_PANEL_URL"), getenv("PTERODACTYL_API_KEY"))

    async def _fetch_client_panel_to_cache(self) -> None:
        try:
            response = await self.pterodactyl.request("GET", getenv("CLIENT_PANEL_URL"), headers={})
        except TimeoutError:
            self._cache["client_is_enabled"] = False
            return logger.error("Не удалось получить информацию о клиентской панели.")

        logger.success("Информация о клиентской панели успешно получена и кеширована!")

        self._cache["client_is_enabled"] = True if response["status"] == 200 else False

    async def _fetch_main_site_to_cache(self) -> None:
        try:
            response = await self.pterodactyl.request("GET", getenv("MAIN_SITE_URL"), headers={})
        except TimeoutError:
            self._cache["site_is_enabled"] = False
            return logger.error("Не удалось получить информацию о главном сайте.")

        logger.success("Информация о главном сайте успешно получена и кеширована!")

        self._cache["site_is_enabled"] = True if response["status"] == 200 else False

    async def _fetch_nodes_to_cache(self) -> None:
        try:
            nodes = await self.pterodactyl.get_nodes()

            for node in nodes:
                location = node["relationships"]["location"]["attributes"]

                if location["id"] not in self._cache["locations"]:
                    self._cache["locations"][location["id"]] = {
                        "nodes": {},
                        "short": location["short"]
                    }

                self._cache["locations"][location["id"]]["nodes"][node["id"]] = node

            logger.success("Информация об узлах успешно получена и кеширована!")
            self._cache["pterodactyl_is_enabled"] = True
        except TimeoutError:
            self._cache["pterodactyl_is_enabled"] = False
            logger.error("Не удалось получить информацию об узлах.")

    async def _fetch_stats(self) -> list[Embed]:
        await self._fetch_client_panel_to_cache()
        await self._fetch_nodes_to_cache()
        await self._fetch_main_site_to_cache()

        disabled = "`❤️ Оффлайн`"
        enabled = "`💚 Онлайн`"

        embeds = [Embed(title="Статистика сайтов", color=0xFF0000).add_field(
            "Главный сайт",
            enabled if self._cache["site_is_enabled"] else disabled
        ).add_field(
            "Клиентская панель",
            enabled if self._cache["client_is_enabled"] else disabled
        ).add_field(
            "Игровая панель",
            enabled if self._cache["pterodactyl_is_enabled"] else disabled
        )]

        for location_id in self._cache["locations"]:
            nodes: dict = self._cache["locations"][location_id]["nodes"]
            short: str = self._cache["locations"][location_id]["short"]

            embed = Embed(title=f"Локация {short}", color=0x2B2D31)

            for node in nodes.values():

                configuration = await self.pterodactyl.get_node_configuration(node["id"])
                is_enabled = await self.pterodactyl.node_is_enabled(
                    scheme=node["scheme"],
                    fqdn=node["fqdn"],
                    daemon_listen=node["daemon_listen"],
                    token=configuration["token"]
                )

                total_servers = len(node["relationships"]["servers"]["data"])

                embed.add_field(
                    node["name"],
                    f"{'`💚 Онлайн`' if is_enabled else '`❤️ Оффлайн`'}\nСерверов: {total_servers}"
                )

            embeds.append(embed)

        embed = Embed(description="by <@834429269132050442>", color=0xFF0000)
        embed.timestamp = datetime.now()

        embeds.append(embed)

        return embeds

    @staticmethod
    def _get_buttons() -> ActionRow[Button]:
        buttons = {
            "Главный сайт": getenv("MAIN_SITE_URL"),
            "Клиентская панель": getenv("CLIENT_PANEL_URL"),
            "Игровая панель": getenv("PTERODACTYL_PANEL_URL")
        }

        return ActionRow(*[
            Button(label=name, url=url, style=ButtonStyle.url) for name, url in buttons.items()
        ])

    @loop(minutes=1)
    async def stats_loop(self) -> None:
        guild = self.bot.get_guild(int(getenv("GUILD_ID")))
        channel: TextChannel = guild.get_channel(int(getenv("CHANNEL_ID")))
        embeds = await self._fetch_stats()

        message = await channel.fetch_message(self._cache["message_id"])

        await message.edit(embeds=embeds, components=self._get_buttons())
        logger.success("Статистика успешно отправлена!")

    @Cog.listener("on_ready")
    async def ready_handler(self) -> None:
        logger.success("Бот запустился!")

        guild = self.bot.get_guild(int(getenv("GUILD_ID")))
        channel: TextChannel = guild.get_channel(int(getenv("CHANNEL_ID")))
        embeds = await self._fetch_stats()

        if self._cache["message_id"] == 0:
            if (await channel.fetch_message(channel.last_message_id)).author.id == self.bot.user.id:
                self._cache["message_id"] = channel.last_message_id
            else:
                message = await channel.send(embeds=embeds, components=self._get_buttons())
                self._cache["message_id"] = message.id

        self.stats_loop.start()


def setup(bot: InteractionBot):
    bot.add_cog(Stats(bot))
